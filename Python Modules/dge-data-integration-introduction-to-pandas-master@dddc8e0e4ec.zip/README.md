This is an introduction to the Python library pandas designed for DGE, DGMP and DGI staff, who have limited or no knowledge of Python. A prerequisite is to this introduction is to have Python (Anaconda distribution) installed on your computer.

To work with this course, please follow these steps

1. Download the data file <a href="https://darwin.escb.eu/livelink/livelink/link/263409111"> une_rt_a_1_Data.csv</a> from Darwin and save it as is on your D:/ drive.
2. Clone or download this repository to your `D:/` drive.
3. In case you downloaded the repository, please unzip it to a folder `D:/dge-data-integration-introduction-to-pandas`
4. Open 'Anaconda Prompt' from the Start Menu
5. When it opens, type `cd /d D:/dge-data-integration-introduction-to-pandas`
6. Type `jupyter notebook` to load the notebook
7. Click on the course


Prepared by colm.bates@ecb.int
